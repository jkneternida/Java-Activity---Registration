package RegistrationForm;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
public class RegForm {

        private String firstname;
        private String lastname;
        private LocalDate birthday;
        private String course;
        private String email_address;



        public String getFirstname() {
            return firstname;
        }

        public void setFirstname(String firstname) {
            String firstname_validation = "^[a-zA-Z]+(?:\\s[a-zA-Z]{1,50}+)*$";
            if (firstname.matches(firstname_validation)) {
                this.firstname = firstname;
            } else {
                System.out.println("Invalid Firstname.");
                System.exit(1);
            }
        }

        public String getLastname() {
            return lastname;
        }

        public void setLastname(String lastname) {
            String lastname_validation = "^[a-zA-Z]+(?:\\s[a-zA-Z]{1,50}+)*$";
            if (lastname.matches(lastname_validation)) {
                this.lastname = lastname;
            } else {
                System.out.println("Invalid Lastname.");
                System.exit(1);
            }
        }

        public LocalDate getBirthday() {
            return birthday;
        }

        public void setBirthday(String birthdayStr) {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
            try {
                LocalDate bday = LocalDate.parse(birthdayStr, formatter);
                Period age = Period.between(bday, LocalDate.now());
                if (age.getYears() >= 16 && age.getYears() <= 25) {
                    this.birthday = bday;
                } else {
                    System.out.println("Error: Birthday should be between 16 and 25 years old.");
                    System.exit(1);
                }
            } catch (Exception e) {
                System.out.println("Error: Invalid birthday format (yyyy/MM/dd)");
                System.exit(1);
            }
        }

        public String getCourse() {
            return course;
        }
        public void setCourse(String course) {
            String course_validation = "^[a-zA-Z]+(?:\\s[a-zA-Z]{1,50}+)*$";
            if (course.matches(course_validation)) {
                this.course = course;
            } else {
                System.out.println("Invalid Course.");
                System.exit(1);
            }
        }

        public String getEmail_address() {
            return email_address;
        }
        public void setEmail_address(String email_address) {
            String email_validation = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$";
            if (email_address.matches(email_validation)) {
                this.email_address = email_address;
            } else {
                System.out.println("Invalid email format.");
                System.exit(1);
            }
        }
        public String getStudentNumber(){
            String year = Integer.toString(LocalDate.now().getYear());
            String month = birthday.format(DateTimeFormatter.ofPattern("dd"));
            String firstLetterSurname = lastname.substring(0,1).toLowerCase();
            return year + "-" + month + "01-" + firstLetterSurname;

        }
    }


