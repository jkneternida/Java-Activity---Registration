package RegistrationForm;

import java.util.Scanner;
public class RegValidation {


        public static void main(String[] args) {

            Scanner sc = new Scanner(System.in);

            RegForm Form = new RegForm();
            System.out.println("REGISTRATION");
            System.out.print("Firstname:");
            Form.setFirstname(sc.nextLine());

            System.out.print("Lastname:");
            Form.setLastname(sc.nextLine());

            System.out.print("Birthdate:");
            Form.setBirthday(sc.nextLine());

            System.out.print("Course:");
            Form.setCourse(sc.nextLine());

            System.out.print("Email Address:");
            Form.setEmail_address(sc.nextLine());

            System.out.println(Form.getStudentNumber());

        }
    }
